
  # Accessible Haptic Watch Design

  This is a code bundle for Accessible Haptic Watch Design. The original project is available at https://www.figma.com/design/X0CRMO5BYTs36iLUgIOLJb/Accessible-Haptic-Watch-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  