import { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

export function MagneticFieldDemo() {
  const [activeCoils, setActiveCoils] = useState<number[]>([]);
  const [showFieldLines, setShowFieldLines] = useState(true);

  const coilGrid = Array.from({ length: 4 }, (_, row) =>
    Array.from({ length: 24 }, (_, col) => ({ row, col, id: row * 24 + col }))
  ).flat();

  const toggleCoil = (id: number) => {
    setActiveCoils(prev =>
      prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]
    );
  };

  const activatePattern = (pattern: 'digit' | 'all' | 'clear') => {
    if (pattern === 'clear') {
      setActiveCoils([]);
    } else if (pattern === 'all') {
      setActiveCoils(coilGrid.map(c => c.id));
    } else if (pattern === 'digit') {
      // Activate a number "8" pattern
      const digit8 = [
        // Top
        0, 1, 2,
        // Middle top
        3, 5, 6, 8,
        // Middle
        9, 10, 11,
        // Middle bottom
        12, 14, 15, 17,
        // Bottom
        18, 19, 20
      ];
      setActiveCoils(digit8);
    }
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700 p-6">
      <div className="mb-6">
        <h3 className="text-white mb-2">Electromagnetic Coil Array</h3>
        <p className="text-slate-400 text-sm">
          Interactive demonstration of the 24×4 electromagnetic grid
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Coil Grid Visualization */}
        <div className="lg:col-span-2">
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-700">
            <div className="flex justify-between items-center mb-4">
              <div className="text-slate-400 text-sm">
                24×4 Coil Array (96 independent coils)
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowFieldLines(!showFieldLines)}
                >
                  {showFieldLines ? 'Hide' : 'Show'} Fields
                </Button>
              </div>
            </div>

            <div className="relative bg-slate-950 rounded-lg p-4 border border-slate-800">
              {/* Grid of coils */}
              <div className="grid grid-cols-24 gap-1">
                {coilGrid.map(coil => {
                  const isActive = activeCoils.includes(coil.id);
                  
                  return (
                    <div key={coil.id} className="relative aspect-square">
                      <motion.button
                        className={`w-full h-full rounded-sm transition-colors ${
                          isActive
                            ? 'bg-red-600 hover:bg-red-500'
                            : 'bg-slate-800 hover:bg-slate-700'
                        }`}
                        onClick={() => toggleCoil(coil.id)}
                        whileTap={{ scale: 0.9 }}
                      >
                        {/* Coil indicator */}
                        <motion.div
                          className={`w-full h-full rounded-full ${
                            isActive ? 'bg-red-400' : 'bg-slate-700'
                          }`}
                          animate={{
                            scale: isActive ? [1, 1.2, 1] : 1,
                          }}
                          transition={{
                            duration: 0.6,
                            repeat: isActive ? Infinity : 0,
                          }}
                        />
                      </motion.button>

                      {/* Magnetic field lines */}
                      {isActive && showFieldLines && (
                        <>
                          <motion.div
                            className="absolute -top-8 left-1/2 -translate-x-1/2 w-px h-8 bg-gradient-to-t from-blue-500/60 to-transparent pointer-events-none"
                            initial={{ opacity: 0, scaleY: 0 }}
                            animate={{ opacity: 1, scaleY: 1 }}
                            exit={{ opacity: 0, scaleY: 0 }}
                          />
                          <motion.div
                            className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-px h-8 bg-gradient-to-b from-red-500/60 to-transparent pointer-events-none"
                            initial={{ opacity: 0, scaleY: 0 }}
                            animate={{ opacity: 1, scaleY: 1 }}
                            exit={{ opacity: 0, scaleY: 0 }}
                          />
                          
                          {/* Radial field */}
                          <motion.div
                            className="absolute inset-0 -m-2 rounded-full border border-purple-500/20 pointer-events-none"
                            animate={{
                              scale: [1, 1.5, 1],
                              opacity: [0.3, 0.1, 0.3],
                            }}
                            transition={{
                              duration: 2,
                              repeat: Infinity,
                            }}
                          />
                        </>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Active coil counter */}
              <div className="mt-4 text-center">
                <Badge variant="outline" className="bg-slate-900/50">
                  {activeCoils.length} / 96 coils active
                </Badge>
              </div>
            </div>

            {/* Preset patterns */}
            <div className="mt-4 flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => activatePattern('digit')}
              >
                Show "8"
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => activatePattern('all')}
              >
                All On
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => activatePattern('clear')}
              >
                Clear
              </Button>
            </div>
          </div>
        </div>

        {/* Technical Information */}
        <div className="space-y-4">
          <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
            <h4 className="text-white mb-3">Coil Specifications</h4>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-slate-400">Type:</dt>
                <dd className="text-white">Micro-coil</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Diameter:</dt>
                <dd className="text-white">2mm</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Wire Gauge:</dt>
                <dd className="text-white">AWG 44</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Turns:</dt>
                <dd className="text-white">~100</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Resistance:</dt>
                <dd className="text-white">50Ω</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Current:</dt>
                <dd className="text-white">20-50mA</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Field Strength:</dt>
                <dd className="text-white">~0.1T</dd>
              </div>
            </dl>
          </div>

          <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
            <h4 className="text-white mb-3">Power Management</h4>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-slate-400 text-sm">Peak Power</span>
                  <span className="text-red-400 text-sm">480mW</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full w-[95%] bg-gradient-to-r from-red-600 to-red-500" />
                </div>
                <p className="text-xs text-slate-500 mt-1">All 96 coils active</p>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-slate-400 text-sm">Typical Use</span>
                  <span className="text-yellow-400 text-sm">120mW</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full w-[24%] bg-gradient-to-r from-yellow-600 to-yellow-500" />
                </div>
                <p className="text-xs text-slate-500 mt-1">~24 coils for digits</p>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-slate-400 text-sm">Standby</span>
                  <span className="text-green-400 text-sm">15mW</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full w-[3%] bg-gradient-to-r from-green-600 to-green-500" />
                </div>
                <p className="text-xs text-slate-500 mt-1">Magnetic locking</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-purple-900/20 border border-purple-700/30 rounded-lg">
            <h4 className="text-purple-400 mb-2 text-sm">Smart Features</h4>
            <ul className="text-slate-300 text-sm space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-purple-500">•</span>
                <span>Individual coil addressing for precise patterns</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-500">•</span>
                <span>PWM control for variable magnetic strength</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-500">•</span>
                <span>Residual magnetism reduces power during display</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-500">•</span>
                <span>Sequential activation for smooth transitions</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Card>
  );
}
