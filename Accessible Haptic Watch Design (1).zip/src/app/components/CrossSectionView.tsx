import { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Label } from './ui/label';

export function CrossSectionView() {
  const [magnetActive, setMagnetActive] = useState(false);
  const [hoveredLayer, setHoveredLayer] = useState<number | null>(null);

  const layers = [
    {
      id: 1,
      name: 'Sapphire Crystal Cover',
      height: 15,
      color: 'bg-blue-200/30',
      borderColor: 'border-blue-400',
      description: 'Scratch-resistant protective layer, anti-reflective coating',
      thickness: '1.5mm'
    },
    {
      id: 2,
      name: 'Flexible Silicone Membrane',
      height: 8,
      color: 'bg-slate-300/40',
      borderColor: 'border-slate-400',
      description: 'Deformable surface that responds to magnetic forces below',
      thickness: '0.5mm'
    },
    {
      id: 3,
      name: 'Magnetic Sand Layer',
      height: 20,
      color: 'bg-amber-600/60',
      borderColor: 'border-amber-500',
      description: 'Ferromagnetic particles (50-100μm) in sealed chambers',
      thickness: '1.2mm',
      particles: true
    },
    {
      id: 4,
      name: 'Separation Grid',
      height: 6,
      color: 'bg-gray-400/50',
      borderColor: 'border-gray-500',
      description: 'Honeycomb structure prevents particle migration',
      thickness: '0.3mm'
    },
    {
      id: 5,
      name: 'Electromagnetic Coil Array',
      height: 25,
      color: 'bg-red-600/40',
      borderColor: 'border-red-500',
      description: '96 individual micro-coils (24×4 grid)',
      thickness: '2mm',
      magnetic: true
    },
    {
      id: 6,
      name: 'Control Circuit Board',
      height: 12,
      color: 'bg-green-600/40',
      borderColor: 'border-green-500',
      description: 'Microcontroller and coil driver circuits',
      thickness: '0.8mm'
    },
    {
      id: 7,
      name: 'Battery & Housing',
      height: 30,
      color: 'bg-slate-700/60',
      borderColor: 'border-slate-600',
      description: 'Li-ion battery (250mAh) and metal casing',
      thickness: '3.5mm'
    }
  ];

  return (
    <Card className="bg-slate-800/50 border-slate-700 p-6">
      <div className="mb-6">
        <h3 className="text-white mb-2">Cross-Section View</h3>
        <p className="text-slate-400 text-sm">
          Interactive layer diagram showing how magnetic sand particles are raised
        </p>
      </div>

      <div className="flex items-center gap-3 mb-6 p-4 bg-slate-900/50 rounded-lg border border-slate-700">
        <Switch 
          id="magnet-toggle"
          checked={magnetActive}
          onCheckedChange={setMagnetActive}
        />
        <Label htmlFor="magnet-toggle" className="text-slate-300 cursor-pointer">
          {magnetActive ? 'Electromagnet Active (Particles Raised)' : 'Electromagnet Inactive (Particles Flat)'}
        </Label>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Visual Cross-Section */}
        <div className="relative">
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-700">
            <div className="text-slate-400 text-sm mb-4 text-center">
              Side View (Magnified)
            </div>
            
            <div className="relative h-[400px] flex flex-col-reverse gap-0">
              {layers.map((layer, index) => (
                <motion.div
                  key={layer.id}
                  className={`relative ${layer.color} ${layer.borderColor} border-2 cursor-pointer transition-all`}
                  style={{ 
                    height: `${layer.height}%`,
                  }}
                  animate={{
                    y: magnetActive && layer.id === 3 ? -8 : 0,
                  }}
                  transition={{ type: 'spring', stiffness: 200, damping: 20 }}
                  onMouseEnter={() => setHoveredLayer(layer.id)}
                  onMouseLeave={() => setHoveredLayer(null)}
                >
                  {/* Layer label */}
                  <div className="absolute left-2 top-1/2 -translate-y-1/2 text-xs text-white/80 font-mono">
                    {layer.name}
                  </div>

                  {/* Particles in sand layer */}
                  {layer.particles && (
                    <div className="absolute inset-0 overflow-hidden">
                      {Array.from({ length: 40 }).map((_, i) => (
                        <motion.div
                          key={i}
                          className="absolute w-1 h-1 bg-amber-800 rounded-full"
                          style={{
                            left: `${(i * 7) % 100}%`,
                            top: '50%',
                          }}
                          animate={{
                            y: magnetActive ? -10 - (i % 3) * 3 : 0,
                            scale: magnetActive ? 1.2 : 1,
                          }}
                          transition={{
                            type: 'spring',
                            stiffness: 150,
                            damping: 15,
                            delay: i * 0.01
                          }}
                        />
                      ))}
                    </div>
                  )}

                  {/* Magnetic field lines */}
                  {layer.magnetic && magnetActive && (
                    <>
                      {Array.from({ length: 12 }).map((_, i) => (
                        <motion.div
                          key={i}
                          className="absolute top-0 w-0.5 bg-gradient-to-t from-red-500/60 to-transparent rounded-full"
                          style={{
                            left: `${8 + i * 7}%`,
                            height: '140%',
                          }}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: [0, 0.6, 0] }}
                          transition={{
                            duration: 1.5,
                            repeat: Infinity,
                            delay: i * 0.1
                          }}
                        />
                      ))}
                    </>
                  )}

                  {/* Coil indicators */}
                  {layer.magnetic && (
                    <div className="absolute inset-0 flex items-center justify-around px-4">
                      {Array.from({ length: 8 }).map((_, i) => (
                        <motion.div
                          key={i}
                          className={`w-2 h-2 rounded-full ${magnetActive ? 'bg-red-500' : 'bg-red-900'}`}
                          animate={{
                            scale: magnetActive ? [1, 1.3, 1] : 1,
                          }}
                          transition={{
                            duration: 0.6,
                            repeat: Infinity,
                            delay: i * 0.1
                          }}
                        />
                      ))}
                    </div>
                  )}
                </motion.div>
              ))}
            </div>

            {/* Dimension arrows */}
            <div className="mt-4 flex justify-between items-center text-slate-500 text-xs">
              <span>↕ Total: 9.8mm</span>
              <span>Touch Surface →</span>
            </div>
          </div>
        </div>

        {/* Layer Details */}
        <div className="space-y-3">
          {layers.map((layer) => (
            <motion.div
              key={layer.id}
              className={`p-4 rounded-lg border transition-all cursor-pointer ${
                hoveredLayer === layer.id
                  ? 'bg-slate-700/50 border-slate-500'
                  : 'bg-slate-900/30 border-slate-700/50'
              }`}
              onMouseEnter={() => setHoveredLayer(layer.id)}
              onMouseLeave={() => setHoveredLayer(null)}
              whileHover={{ x: 4 }}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded ${layer.color} ${layer.borderColor} border`} />
                  <h4 className="text-white text-sm">{layer.name}</h4>
                </div>
                <span className="text-amber-400 text-xs font-mono">{layer.thickness}</span>
              </div>
              <p className="text-slate-400 text-xs leading-relaxed">
                {layer.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Technical Notes */}
      <div className="mt-6 p-4 bg-amber-900/20 border border-amber-700/30 rounded-lg">
        <h4 className="text-amber-400 mb-2 text-sm">How Particles Rise:</h4>
        <ul className="text-slate-300 text-sm space-y-1">
          <li className="flex items-start gap-2">
            <span className="text-amber-500">1.</span>
            <span>Electromagnetic coils activate beneath specific positions</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500">2.</span>
            <span>Magnetic field pulls ferromagnetic sand particles upward</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500">3.</span>
            <span>Flexible membrane deforms, creating raised tactile bumps (1-2mm height)</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500">4.</span>
            <span>Pattern remains stable with minimal power (magnetic locking)</span>
          </li>
        </ul>
      </div>
    </Card>
  );
}
