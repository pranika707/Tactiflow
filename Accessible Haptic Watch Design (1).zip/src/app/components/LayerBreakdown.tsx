import { useState } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Slider } from './ui/slider';

export function LayerBreakdown() {
  const [zoomLevel, setZoomLevel] = useState(50);
  const [magnetStrength, setMagnetStrength] = useState(75);

  return (
    <Card className="bg-slate-800/50 border-slate-700 p-6">
      <div className="mb-6">
        <h3 className="text-white mb-2">Particle-Level Detail</h3>
        <p className="text-slate-400 text-sm">
          Microscopic view of the magnetic sand particle mechanism
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Particle Visualization */}
        <div className="bg-slate-900 rounded-lg p-6 border border-slate-700">
          <div className="text-slate-400 text-sm mb-4 text-center">
            Microscopic View (50-100μm particles)
          </div>
          
          <div className="relative h-[400px] bg-slate-950 rounded-lg overflow-hidden border border-slate-800">
            {/* Membrane surface */}
            <motion.div
              className="absolute inset-x-0 top-0 h-12 bg-gradient-to-b from-slate-700/40 to-transparent"
              animate={{
                scaleY: 1 + (magnetStrength / 200),
              }}
              style={{ transformOrigin: 'top' }}
            />

            {/* Magnetic sand particles */}
            <div className="absolute inset-0 p-4">
              {Array.from({ length: 30 }).map((_, i) => {
                const baseX = (i % 6) * 16 + 8;
                const baseY = Math.floor(i / 6) * 16 + 50;
                const magneticInfluence = magnetStrength / 100;
                const particleDelay = i * 0.02;
                
                return (
                  <motion.div
                    key={i}
                    className="absolute"
                    style={{
                      left: `${baseX}%`,
                    }}
                    animate={{
                      y: baseY - (magneticInfluence * 80) - (i % 3) * 10,
                    }}
                    transition={{
                      type: 'spring',
                      stiffness: 100,
                      damping: 15,
                      delay: particleDelay
                    }}
                  >
                    {/* Particle body */}
                    <motion.div
                      className="relative"
                      animate={{
                        scale: [1, 1.05, 1],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        delay: particleDelay
                      }}
                    >
                      {/* Core */}
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-amber-600 to-amber-900 relative">
                        {/* Iron coating visualization */}
                        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-gray-400/40 to-transparent" />
                        
                        {/* Magnetic field indicator */}
                        {magnetStrength > 30 && (
                          <>
                            <motion.div
                              className="absolute -top-8 left-1/2 -translate-x-1/2 w-0.5 h-8 bg-gradient-to-t from-blue-500/60 to-transparent"
                              animate={{
                                opacity: [0.3, 0.7, 0.3],
                              }}
                              transition={{
                                duration: 1,
                                repeat: Infinity,
                                delay: particleDelay
                              }}
                            />
                            <motion.div
                              className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-0.5 h-8 bg-gradient-to-b from-red-500/60 to-transparent"
                              animate={{
                                opacity: [0.3, 0.7, 0.3],
                              }}
                              transition={{
                                duration: 1,
                                repeat: Infinity,
                                delay: particleDelay
                              }}
                            />
                          </>
                        )}
                      </div>

                      {/* Glow effect when magnetized */}
                      {magnetStrength > 50 && (
                        <motion.div
                          className="absolute inset-0 rounded-full bg-amber-500/30 blur-md"
                          animate={{
                            scale: [1, 1.3, 1],
                            opacity: [0.3, 0.6, 0.3],
                          }}
                          transition={{
                            duration: 1.5,
                            repeat: Infinity,
                            delay: particleDelay
                          }}
                        />
                      )}
                    </motion.div>
                  </motion.div>
                );
              })}
            </div>

            {/* Electromagnetic field visualization */}
            {magnetStrength > 20 && (
              <div className="absolute bottom-0 inset-x-0 h-32 pointer-events-none">
                {Array.from({ length: 15 }).map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute bottom-0 w-1 bg-gradient-to-t from-blue-600/40 via-purple-600/40 to-transparent"
                    style={{
                      left: `${i * 6.67}%`,
                      height: `${magnetStrength * 1.2}%`,
                    }}
                    animate={{
                      opacity: [0.2, 0.5, 0.2],
                      scaleY: [0.95, 1.05, 0.95],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      delay: i * 0.05
                    }}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="mt-4 space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <label className="text-slate-300 text-sm">Magnet Strength</label>
                <span className="text-amber-400 text-sm">{magnetStrength}%</span>
              </div>
              <Slider
                value={[magnetStrength]}
                onValueChange={(value) => setMagnetStrength(value[0])}
                min={0}
                max={100}
                step={1}
              />
            </div>
          </div>
        </div>

        {/* Technical Details */}
        <div className="space-y-4">
          <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
            <h4 className="text-white mb-3">Particle Composition</h4>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-slate-400 text-sm">Silica Core</span>
                  <span className="text-amber-400 text-sm">60%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full w-[60%] bg-gradient-to-r from-amber-600 to-amber-500" />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-slate-400 text-sm">Iron Coating</span>
                  <span className="text-gray-400 text-sm">35%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full w-[35%] bg-gradient-to-r from-gray-500 to-gray-400" />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-slate-400 text-sm">Polymer Binder</span>
                  <span className="text-blue-400 text-sm">5%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full w-[5%] bg-gradient-to-r from-blue-500 to-blue-400" />
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
            <h4 className="text-white mb-3">Particle Specifications</h4>
            <dl className="space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-slate-400">Size Range:</dt>
                <dd className="text-white">50-100 μm</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Magnetic Susceptibility:</dt>
                <dd className="text-white">High (χ &gt; 1000)</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Density:</dt>
                <dd className="text-white">2.8 g/cm³</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Response Time:</dt>
                <dd className="text-white">&lt; 50ms</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-400">Particles per cell:</dt>
                <dd className="text-white">~500-800</dd>
              </div>
            </dl>
          </div>

          <div className="p-4 bg-blue-900/20 border border-blue-700/30 rounded-lg">
            <h4 className="text-blue-400 mb-2 text-sm">Magnetic Properties</h4>
            <ul className="text-slate-300 text-sm space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-blue-500">•</span>
                <span>Particles align with magnetic field lines</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-500">•</span>
                <span>Iron coating provides strong ferromagnetic response</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-500">•</span>
                <span>Clusters form at high field strength for increased height</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-500">•</span>
                <span>Residual magnetism holds pattern with minimal power</span>
              </li>
            </ul>
          </div>

          <div className="p-4 bg-amber-900/20 border border-amber-700/30 rounded-lg">
            <h4 className="text-amber-400 mb-2 text-sm">Tactile Response</h4>
            <ul className="text-slate-300 text-sm space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-amber-500">•</span>
                <span>Raised bumps: 1-2mm height</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-500">•</span>
                <span>Surface feels slightly textured when raised</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-500">•</span>
                <span>Smooth and flat when deactivated</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-500">•</span>
                <span>Temperature neutral (no heat generation)</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Card>
  );
}
