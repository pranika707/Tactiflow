import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Heart, 
  Activity, 
  Footprints, 
  Moon, 
  Volume2, 
  Zap, 
  MapPin, 
  Bell, 
  Thermometer,
  Droplets,
  Wind,
  Sun,
  Timer,
  Calendar,
  Compass,
  Battery
} from 'lucide-react';

export function AdditionalFeatures() {
  const features = [
    {
      category: 'Health & Fitness',
      icon: Heart,
      color: 'bg-red-500',
      items: [
        {
          name: 'Heart Rate Monitor',
          icon: Heart,
          description: 'Continuous heart rate tracking with haptic alerts for abnormal readings',
          accessibility: 'Voice feedback and vibration patterns for different heart rate zones'
        },
        {
          name: 'Step Counter',
          icon: Footprints,
          description: 'Accurate pedometer with daily goal tracking and achievement notifications',
          accessibility: 'Hourly step count announcements via voice assistant'
        },
        {
          name: 'Activity Tracking',
          icon: Activity,
          description: 'Automatic detection of walking, running, cycling, and swimming activities',
          accessibility: 'Tactile feedback when activity goals are reached'
        },
        {
          name: 'Sleep Analysis',
          icon: Moon,
          description: 'Tracks sleep stages, duration, and quality with smart wake alarms',
          accessibility: 'Gentle haptic vibration alarm that gradually increases'
        }
      ]
    },
    {
      category: 'Smart Notifications',
      icon: Bell,
      color: 'bg-blue-500',
      items: [
        {
          name: 'Smart Alerts',
          icon: Bell,
          description: 'Customizable haptic patterns for calls, messages, and app notifications',
          accessibility: 'Unique vibration signatures for different contacts and apps'
        },
        {
          name: 'Voice Assistant',
          icon: Volume2,
          description: 'Built-in voice assistant for hands-free control and information',
          accessibility: 'Complete voice-driven interface for all watch functions'
        },
        {
          name: 'Calendar Integration',
          icon: Calendar,
          description: 'Event reminders with customizable advance notifications',
          accessibility: 'Spoken event details and haptic countdown alerts'
        },
        {
          name: 'Timer & Stopwatch',
          icon: Timer,
          description: 'Multiple timers with distinct haptic patterns for each',
          accessibility: 'Voice-controlled timer setting and interval announcements'
        }
      ]
    },
    {
      category: 'Environmental',
      icon: Thermometer,
      color: 'bg-green-500',
      items: [
        {
          name: 'Temperature',
          icon: Thermometer,
          description: 'Real-time temperature monitoring for indoor and outdoor conditions',
          accessibility: 'Voice announcement of current temperature on demand'
        },
        {
          name: 'Humidity Sensor',
          icon: Droplets,
          description: 'Tracks ambient humidity levels for comfort monitoring',
          accessibility: 'Haptic alerts when humidity reaches uncomfortable levels'
        },
        {
          name: 'UV Index',
          icon: Sun,
          description: 'UV radiation monitoring with sun exposure warnings',
          accessibility: 'Voice alerts when UV levels require sun protection'
        },
        {
          name: 'Air Pressure',
          icon: Wind,
          description: 'Barometric pressure sensor for weather prediction and altitude',
          accessibility: 'Weather change notifications via haptic patterns'
        }
      ]
    },
    {
      category: 'Navigation & Safety',
      icon: Compass,
      color: 'bg-purple-500',
      items: [
        {
          name: 'Compass',
          icon: Compass,
          description: 'Digital compass with haptic directional feedback',
          accessibility: 'Vibration patterns indicate cardinal directions when tilted'
        },
        {
          name: 'GPS Tracking',
          icon: MapPin,
          description: 'Built-in GPS for route tracking and location sharing',
          accessibility: 'Audio navigation instructions and tactile turn alerts'
        },
        {
          name: 'Emergency SOS',
          icon: Zap,
          description: 'One-button emergency contact with location sharing',
          accessibility: 'Accessible emergency activation via long-press or voice command'
        },
        {
          name: 'Fall Detection',
          icon: Activity,
          description: 'Automatic fall detection with emergency contact notification',
          accessibility: 'Voice check-in after detected fall with auto-alert if unresponsive'
        }
      ]
    }
  ];

  const batteryFeatures = [
    { label: 'Standard Use', duration: '7 days', description: 'Typical daily usage with all features' },
    { label: 'Power Save Mode', duration: '14 days', description: 'Time display only with reduced haptics' },
    { label: 'Heavy Use', duration: '4 days', description: 'GPS tracking and continuous monitoring' },
    { label: 'Charge Time', duration: '2 hours', description: 'Full charge via wireless charging pad' }
  ];

  return (
    <div className="space-y-6">
      {/* Feature Categories */}
      {features.map((category, catIdx) => {
        const CategoryIcon = category.icon;
        return (
          <Card key={catIdx} className="bg-slate-800/50 border-slate-700 p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className={`p-2 rounded-lg ${category.color} bg-opacity-20`}>
                <CategoryIcon className={`w-5 h-5 ${category.color.replace('bg-', 'text-')}`} />
              </div>
              <h3 className="text-white">{category.category}</h3>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {category.items.map((item, itemIdx) => {
                const ItemIcon = item.icon;
                return (
                  <div
                    key={itemIdx}
                    className="p-4 bg-slate-900/50 rounded-lg border border-slate-700/50 hover:border-slate-600 transition-all"
                  >
                    <div className="flex items-start gap-3 mb-3">
                      <div className="mt-1">
                        <ItemIcon className="w-4 h-4 text-amber-500" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-white text-sm mb-1">{item.name}</h4>
                        <p className="text-slate-400 text-xs leading-relaxed mb-2">
                          {item.description}
                        </p>
                      </div>
                    </div>
                    <div className="pl-7">
                      <Badge variant="outline" className="bg-blue-900/20 text-blue-400 border-blue-700/50 text-xs">
                        Accessible
                      </Badge>
                      <p className="text-slate-500 text-xs mt-2 leading-relaxed">
                        {item.accessibility}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        );
      })}

      {/* Battery Life */}
      <Card className="bg-slate-800/50 border-slate-700 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-yellow-500 bg-opacity-20">
            <Battery className="w-5 h-5 text-yellow-500" />
          </div>
          <h3 className="text-white">Battery Life</h3>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {batteryFeatures.map((feature, idx) => (
            <div
              key={idx}
              className="p-4 bg-slate-900/50 rounded-lg border border-slate-700/50 text-center"
            >
              <div className="text-slate-400 text-sm mb-2">{feature.label}</div>
              <div className="text-2xl text-amber-400 mb-2">{feature.duration}</div>
              <p className="text-slate-500 text-xs">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-amber-900/20 border border-amber-700/30 rounded-lg">
          <h4 className="text-amber-400 mb-2 text-sm">Power Management</h4>
          <ul className="text-slate-300 text-sm space-y-2">
            <li className="flex items-start gap-2">
              <span className="text-amber-500">•</span>
              <span>Wireless Qi charging (5W)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-500">•</span>
              <span>Solar assist charging extends battery by 20%</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-500">•</span>
              <span>Intelligent power management learns usage patterns</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-500">•</span>
              <span>Low battery alerts with remaining time estimation</span>
            </li>
          </ul>
        </div>
      </Card>


    </div>
  );
}
