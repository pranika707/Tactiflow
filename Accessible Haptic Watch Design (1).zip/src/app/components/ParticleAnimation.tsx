import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Play, Pause, RotateCcw } from 'lucide-react';

export function ParticleAnimation() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    {
      title: 'Step 1: Initial State',
      description: 'Particles rest at the bottom, evenly distributed',
      magnetStrength: 0,
    },
    {
      title: 'Step 2: Field Activation',
      description: 'Electromagnetic field begins to build',
      magnetStrength: 30,
    },
    {
      title: 'Step 3: Particle Alignment',
      description: 'Particles align with magnetic field lines',
      magnetStrength: 60,
    },
    {
      title: 'Step 4: Membrane Deformation',
      description: 'Flexible membrane rises with particles',
      magnetStrength: 85,
    },
    {
      title: 'Step 5: Tactile Pattern',
      description: 'Stable raised pattern formed (1-2mm height)',
      magnetStrength: 100,
    },
  ];

  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setCurrentStep(prev => {
          if (prev >= steps.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, 2000);
      return () => clearInterval(interval);
    }
  }, [isPlaying, steps.length]);

  const reset = () => {
    setCurrentStep(0);
    setIsPlaying(false);
  };

  const step = steps[currentStep];
  const magnetStrength = step.magnetStrength;

  return (
    <Card className="bg-slate-800/50 border-slate-700 p-6">
      <div className="mb-6">
        <h3 className="text-white mb-2">Particle Raising Animation</h3>
        <p className="text-slate-400 text-sm">
          Step-by-step visualization of how the tactile surface is formed
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Animation Display */}
        <div className="lg:col-span-2">
          <div className="bg-slate-900 rounded-lg p-6 border border-slate-700">
            {/* Animation area */}
            <div className="relative h-[400px] bg-slate-950 rounded-lg overflow-hidden border border-slate-800 mb-4">
              {/* Membrane layer */}
              <motion.div
                className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-slate-600/50 via-slate-700/30 to-transparent border-b-2 border-slate-600/50"
                animate={{
                  y: magnetStrength > 0 ? -magnetStrength * 0.4 : 0,
                }}
                transition={{ type: 'spring', stiffness: 100, damping: 20 }}
              >
                {/* Membrane texture */}
                <div className="absolute inset-0 opacity-30">
                  {Array.from({ length: 20 }).map((_, i) => (
                    <div
                      key={i}
                      className="absolute inset-y-0 w-px bg-slate-500"
                      style={{ left: `${i * 5}%` }}
                    />
                  ))}
                </div>
              </motion.div>

              {/* Sand particles */}
              <div className="absolute inset-0">
                {Array.from({ length: 36 }).map((_, i) => {
                  const col = i % 12;
                  const row = Math.floor(i / 12);
                  const baseY = 320 + row * 20;
                  const particleRise = (magnetStrength / 100) * (200 + (i % 3) * 20);
                  
                  return (
                    <motion.div
                      key={i}
                      className="absolute"
                      style={{
                        left: `${8 + col * 7.5}%`,
                      }}
                      animate={{
                        y: baseY - particleRise,
                      }}
                      transition={{
                        type: 'spring',
                        stiffness: 150,
                        damping: 20,
                        delay: i * 0.015
                      }}
                    >
                      <motion.div
                        className="w-4 h-4 rounded-full bg-gradient-to-br from-amber-600 to-amber-900 relative"
                        animate={{
                          scale: magnetStrength > 50 ? [1, 1.1, 1] : 1,
                        }}
                        transition={{
                          duration: 1,
                          repeat: Infinity,
                          delay: i * 0.05
                        }}
                      >
                        {/* Glow effect */}
                        {magnetStrength > 60 && (
                          <motion.div
                            className="absolute inset-0 rounded-full bg-amber-500/40 blur-sm"
                            animate={{
                              scale: [1, 1.5, 1],
                              opacity: [0.4, 0.7, 0.4],
                            }}
                            transition={{
                              duration: 1.5,
                              repeat: Infinity,
                              delay: i * 0.03
                            }}
                          />
                        )}
                      </motion.div>
                    </motion.div>
                  );
                })}
              </div>

              {/* Electromagnetic coils at bottom */}
              <div className="absolute bottom-4 inset-x-0 flex justify-around px-8">
                {Array.from({ length: 12 }).map((_, i) => (
                  <motion.div
                    key={i}
                    className="relative"
                  >
                    <motion.div
                      className={`w-3 h-3 rounded-full ${
                        magnetStrength > 0 ? 'bg-red-600' : 'bg-red-900'
                      }`}
                      animate={{
                        scale: magnetStrength > 0 ? [1, 1.3, 1] : 1,
                        boxShadow: magnetStrength > 0 
                          ? ['0 0 5px rgba(220, 38, 38, 0.5)', '0 0 15px rgba(220, 38, 38, 0.8)', '0 0 5px rgba(220, 38, 38, 0.5)']
                          : '0 0 0px rgba(220, 38, 38, 0)',
                      }}
                      transition={{
                        duration: 1,
                        repeat: Infinity,
                        delay: i * 0.08
                      }}
                    />
                    
                    {/* Magnetic field lines */}
                    {magnetStrength > 20 && (
                      <motion.div
                        className="absolute bottom-full left-1/2 -translate-x-1/2 w-0.5 bg-gradient-to-t from-blue-500/60 via-purple-500/40 to-transparent"
                        style={{
                          height: `${magnetStrength * 2.5}px`,
                        }}
                        animate={{
                          opacity: [0.3, 0.7, 0.3],
                        }}
                        transition={{
                          duration: 1.5,
                          repeat: Infinity,
                          delay: i * 0.05
                        }}
                      />
                    )}
                  </motion.div>
                ))}
              </div>

              {/* Height indicator */}
              {magnetStrength > 0 && (
                <div className="absolute right-4 top-1/2 -translate-y-1/2">
                  <motion.div
                    className="flex items-center gap-2"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                  >
                    <div className="h-px w-4 bg-amber-500" />
                    <div className="text-amber-400 text-xs font-mono bg-slate-900/80 px-2 py-1 rounded">
                      {(magnetStrength / 50).toFixed(1)}mm
                    </div>
                    <div className="h-px w-4 bg-amber-500" />
                  </motion.div>
                </div>
              )}
            </div>

            {/* Controls */}
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                onClick={() => setIsPlaying(!isPlaying)}
                disabled={currentStep >= steps.length - 1 && !isPlaying}
              >
                {isPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                {isPlaying ? 'Pause' : 'Play'}
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={reset}
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
        </div>

        {/* Step Information */}
        <div className="space-y-4">
          <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
            <h4 className="text-white mb-3">Animation Progress</h4>
            <div className="space-y-3">
              {steps.map((s, index) => (
                <motion.div
                  key={index}
                  className={`p-3 rounded-lg border transition-all ${
                    index === currentStep
                      ? 'bg-amber-900/30 border-amber-600'
                      : index < currentStep
                      ? 'bg-green-900/20 border-green-700/30'
                      : 'bg-slate-800/30 border-slate-700/30'
                  }`}
                  animate={{
                    scale: index === currentStep ? 1.02 : 1,
                  }}
                >
                  <div className="flex items-start gap-2">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${
                      index === currentStep
                        ? 'bg-amber-600 text-white'
                        : index < currentStep
                        ? 'bg-green-600 text-white'
                        : 'bg-slate-700 text-slate-400'
                    }`}>
                      {index < currentStep ? '✓' : index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="text-white text-sm mb-1">{s.title}</div>
                      <div className="text-slate-400 text-xs">{s.description}</div>
                      <div className="mt-2 flex items-center gap-2">
                        <div className="h-1 flex-1 bg-slate-800 rounded-full overflow-hidden">
                          <motion.div
                            className="h-full bg-gradient-to-r from-red-600 to-amber-500"
                            animate={{
                              width: index === currentStep ? `${s.magnetStrength}%` : index < currentStep ? '100%' : '0%'
                            }}
                            transition={{ duration: 0.5 }}
                          />
                        </div>
                        <span className="text-xs text-slate-500 w-10">{s.magnetStrength}%</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <div className="p-4 bg-blue-900/20 border border-blue-700/30 rounded-lg">
            <h4 className="text-blue-400 mb-2 text-sm">Key Principles</h4>
            <ul className="text-slate-300 text-sm space-y-2">
              <li className="flex items-start gap-2">
                <span className="text-blue-500">•</span>
                <span>Electromagnetic force overcomes gravity</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-500">•</span>
                <span>Particles cluster at field maxima</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-500">•</span>
                <span>Membrane flexibility enables deformation</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-500">•</span>
                <span>Pattern stabilizes through magnetic locking</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </Card>
  );
}
