import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { motion } from 'motion/react';
import { Clock, Bell, MessageSquare, Activity } from 'lucide-react';

interface HapticDemoProps {
  hours: number;
  minutes: number;
}

export function HapticDemo({ hours, minutes }: HapticDemoProps) {
  const [activePattern, setActivePattern] = useState<string | null>(null);

  const hapticPatterns = [
    {
      id: 'hourly',
      icon: Clock,
      label: 'Hourly Chime',
      description: 'Single pulse every hour',
      pattern: [1],
      color: 'bg-blue-500'
    },
    {
      id: 'alarm',
      icon: Bell,
      label: 'Alarm',
      description: 'Three strong pulses',
      pattern: [1, 1, 1],
      color: 'bg-red-500'
    },
    {
      id: 'notification',
      icon: MessageSquare,
      label: 'Notification',
      description: 'Two gentle taps',
      pattern: [0.6, 0.6],
      color: 'bg-green-500'
    },
    {
      id: 'confirm',
      icon: Activity,
      label: 'Confirmation',
      description: 'Short-long pulse',
      pattern: [0.5, 1],
      color: 'bg-purple-500'
    }
  ];

  const triggerPattern = (patternId: string, pattern: number[]) => {
    setActivePattern(patternId);
    
    // Simulate haptic feedback
    if ('vibrate' in navigator) {
      const vibrationPattern = pattern.map(intensity => intensity * 200);
      navigator.vibrate(vibrationPattern);
    }

    setTimeout(() => {
      setActivePattern(null);
    }, pattern.length * 300);
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700 p-6">
      <h3 className="text-white mb-4">Haptic Feedback System</h3>
      
      <div className="space-y-4 mb-6">
        <p className="text-slate-300">
          The watch uses precise haptic vibrations to notify users without sound. 
          Different patterns identify different event types.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-3 mb-6">
        {hapticPatterns.map(pattern => {
          const Icon = pattern.icon;
          return (
            <Button
              key={pattern.id}
              variant="outline"
              className="h-auto p-4 justify-start text-left border-slate-700 hover:border-slate-600 hover:bg-slate-700/50"
              onClick={() => triggerPattern(pattern.id, pattern.pattern)}
            >
              <div className="flex items-start gap-3 w-full">
                <div className={`p-2 rounded-lg ${pattern.color} bg-opacity-20`}>
                  <Icon className={`w-5 h-5 ${pattern.color.replace('bg-', 'text-')}`} />
                </div>
                <div className="flex-1">
                  <div className="text-white mb-1">{pattern.label}</div>
                  <div className="text-slate-400 text-sm">{pattern.description}</div>
                  <div className="flex gap-1 mt-2">
                    {pattern.pattern.map((intensity, idx) => (
                      <motion.div
                        key={idx}
                        className={`h-2 rounded ${pattern.color}`}
                        style={{ 
                          width: `${intensity * 30}px`,
                          opacity: activePattern === pattern.id ? 1 : 0.3
                        }}
                        animate={
                          activePattern === pattern.id
                            ? {
                                opacity: [0.3, 1, 0.3],
                              }
                            : {}
                        }
                        transition={{
                          duration: 0.3,
                          delay: idx * 0.3,
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </Button>
          );
        })}
      </div>

      <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700/50">
        <h4 className="text-white mb-3">Accessibility Features</h4>
        <ul className="space-y-2 text-slate-300 text-sm">
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-0.5">•</span>
            <span>Customizable haptic intensity (light, medium, strong)</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-0.5">•</span>
            <span>Tactile markers at 12, 3, 6, and 9 o'clock positions</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-0.5">•</span>
            <span>Voice time announcement via button press</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-0.5">•</span>
            <span>Raised bezel markers for orientation</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-0.5">•</span>
            <span>Adaptive contrast mode for low vision users</span>
          </li>
        </ul>
      </div>
    </Card>
  );
}
