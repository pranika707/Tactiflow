import { useState, useEffect } from 'react';
import { motion } from 'motion/react';

interface WatchFaceProps {
  hours: number;
  minutes: number;
}

export function WatchFace({ hours, minutes }: WatchFaceProps) {
  const [sandParticles, setSandParticles] = useState<{ x: number; y: number; active: boolean; id: number }[]>([]);

  // Generate sand particles grid
  useEffect(() => {
    const particles = [];
    const gridSize = 24; // 24x4 grid for Braille-like display
    const rows = 4;
    
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < gridSize; col++) {
        particles.push({
          x: col,
          y: row,
          active: false,
          id: row * gridSize + col
        });
      }
    }
    setSandParticles(particles);
  }, []);

  // Update particle activation based on time
  useEffect(() => {
    setSandParticles(prev => prev.map(particle => {
      const col = particle.x;
      const row = particle.y;
      
      // Display format: HH:MM (Braille-style dots)
      let active = false;

      // Hours tens digit (columns 0-2)
      if (col >= 0 && col < 3) {
        active = isActiveDot(Math.floor(hours / 10), col, row);
      }
      // Hours ones digit (columns 3-5)
      else if (col >= 3 && col < 6) {
        active = isActiveDot(hours % 10, col - 3, row);
      }
      // Separator dots (column 7)
      else if (col === 7) {
        active = row === 1 || row === 2;
      }
      // Minutes tens digit (columns 9-11)
      else if (col >= 9 && col < 12) {
        active = isActiveDot(Math.floor(minutes / 10), col - 9, row);
      }
      // Minutes ones digit (columns 12-14)
      else if (col >= 12 && col < 15) {
        active = isActiveDot(minutes % 10, col - 12, row);
      }

      return { ...particle, active };
    }));
  }, [hours, minutes]);

  // Braille-like number patterns (simplified for 3x4 grid per digit)
  function isActiveDot(digit: number, col: number, row: number): boolean {
    const patterns: { [key: number]: boolean[][] } = {
      0: [
        [true, true, true],
        [true, false, true],
        [true, false, true],
        [true, true, true]
      ],
      1: [
        [false, true, false],
        [true, true, false],
        [false, true, false],
        [false, true, false]
      ],
      2: [
        [true, true, true],
        [false, false, true],
        [true, true, true],
        [true, false, false]
      ],
      3: [
        [true, true, true],
        [false, false, true],
        [false, true, true],
        [true, true, true]
      ],
      4: [
        [true, false, true],
        [true, false, true],
        [true, true, true],
        [false, false, true]
      ],
      5: [
        [true, true, true],
        [true, false, false],
        [true, true, true],
        [false, false, true]
      ],
      6: [
        [true, true, true],
        [true, false, false],
        [true, true, true],
        [true, false, true]
      ],
      7: [
        [true, true, true],
        [false, false, true],
        [false, true, false],
        [true, false, false]
      ],
      8: [
        [true, true, true],
        [true, false, true],
        [true, true, true],
        [true, false, true]
      ],
      9: [
        [true, true, true],
        [true, false, true],
        [true, true, true],
        [false, false, true]
      ]
    };

    return patterns[digit]?.[row]?.[col] || false;
  }

  return (
    <div className="relative">
      {/* Watch Container */}
      <div className="relative mx-auto w-full max-w-md aspect-square">
        {/* Watch Body */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-slate-700 to-slate-900 shadow-2xl">
          {/* Inner bezel */}
          <div className="absolute inset-4 rounded-full bg-gradient-to-br from-slate-800 to-slate-950 shadow-inner">
            {/* Display area */}
            <div className="absolute inset-8 rounded-2xl bg-slate-900 shadow-2xl overflow-hidden">
              {/* Grid of sand particles */}
              <div className="relative w-full h-full p-4">
                <div className="grid grid-cols-24 gap-1 h-full">
                  {sandParticles.map(particle => (
                    <motion.div
                      key={particle.id}
                      className="relative"
                      initial={false}
                    >
                      <motion.div
                        className={`w-full h-full rounded-full ${
                          particle.active 
                            ? 'bg-amber-600 shadow-lg shadow-amber-500/50' 
                            : 'bg-slate-800/30'
                        }`}
                        animate={{
                          scale: particle.active ? 1 : 0.6,
                          y: particle.active ? -2 : 0,
                        }}
                        transition={{
                          type: 'spring',
                          stiffness: 300,
                          damping: 20,
                          delay: particle.active ? particle.x * 0.01 : 0
                        }}
                      />
                      {particle.active && (
                        <motion.div
                          className="absolute inset-0 rounded-full bg-amber-400/30 blur-sm"
                          animate={{
                            opacity: [0.3, 0.6, 0.3],
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: 'easeInOut'
                          }}
                        />
                      )}
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Touch guidance overlay */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 text-slate-600 text-xs">
                Touch to Read
              </div>
            </div>
          </div>
        </div>

        {/* Watch band */}
        <div className="absolute -left-8 top-1/2 -translate-y-1/2 w-8 h-32 bg-gradient-to-r from-slate-900 to-slate-700 rounded-l-lg shadow-lg" />
        <div className="absolute -right-8 top-1/2 -translate-y-1/2 w-8 h-32 bg-gradient-to-l from-slate-900 to-slate-700 rounded-r-lg shadow-lg" />
      </div>

      {/* Time Display (for sighted users) */}
      <div className="text-center mt-6">
        <div className="text-slate-400 mb-2">Current Display</div>
        <div className="text-white text-4xl font-mono">
          {hours.toString().padStart(2, '0')}:{minutes.toString().padStart(2, '0')}
        </div>
        <div className="text-slate-500 text-sm mt-2">
          Raised sand particles form tactile numbers
        </div>
      </div>
    </div>
  );
}
