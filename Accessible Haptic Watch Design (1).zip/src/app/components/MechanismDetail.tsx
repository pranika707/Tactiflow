import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card } from './ui/card';
import { CrossSectionView } from './CrossSectionView';
import { ParticleAnimation } from './ParticleAnimation';
import { MagneticFieldDemo } from './MagneticFieldDemo';
import { LayerBreakdown } from './LayerBreakdown';
import { Layers, Magnet, Play, Microscope } from 'lucide-react';

export function MechanismDetail() {
  return (
    <div className="w-full">
      <Tabs defaultValue="cross-section" className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-slate-800/50">
          <TabsTrigger value="cross-section" className="data-[state=active]:bg-slate-700">
            <Layers className="w-4 h-4 mr-2" />
            Cross-Section
          </TabsTrigger>
          <TabsTrigger value="particle" className="data-[state=active]:bg-slate-700">
            <Microscope className="w-4 h-4 mr-2" />
            Particle Detail
          </TabsTrigger>
          <TabsTrigger value="magnetic" className="data-[state=active]:bg-slate-700">
            <Magnet className="w-4 h-4 mr-2" />
            Magnetic Field
          </TabsTrigger>
          <TabsTrigger value="animation" className="data-[state=active]:bg-slate-700">
            <Play className="w-4 h-4 mr-2" />
            Animation
          </TabsTrigger>
        </TabsList>

        <TabsContent value="cross-section" className="mt-6">
          <CrossSectionView />
        </TabsContent>

        <TabsContent value="particle" className="mt-6">
          <LayerBreakdown />
        </TabsContent>

        <TabsContent value="magnetic" className="mt-6">
          <MagneticFieldDemo />
        </TabsContent>

        <TabsContent value="animation" className="mt-6">
          <ParticleAnimation />
        </TabsContent>
      </Tabs>
    </div>
  );
}
