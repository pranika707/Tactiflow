import { useState, useEffect } from 'react';
import { WatchFace } from './WatchFace';
import { TechnicalSpecs } from './TechnicalSpecs';
import { HapticDemo } from './HapticDemo';
import { MechanismDetail } from './MechanismDetail';
import { AdditionalFeatures } from './AdditionalFeatures';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card } from './ui/card';
import { Clock, Waves, Vibrate, Info } from 'lucide-react';

export function WatchDesign() {
  const [hours, setHours] = useState(10);
  const [minutes, setMinutes] = useState(30);
  const [useRealTime, setUseRealTime] = useState(false);

  useEffect(() => {
    if (useRealTime) {
      const interval = setInterval(() => {
        const now = new Date();
        setHours(now.getHours());
        setMinutes(now.getMinutes());
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [useRealTime]);

  const toggleRealTime = () => {
    if (!useRealTime) {
      const now = new Date();
      setHours(now.getHours());
      setMinutes(now.getMinutes());
    }
    setUseRealTime(!useRealTime);
  };

  return (
    <div className="w-full min-h-screen p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-white mb-2">TactiFlow</h1>
          <p className="text-slate-500 text-sm mb-4">by pranika</p>
          <p className="text-slate-400 max-w-2xl mx-auto">
            An accessible timepiece using magnetic sand technology to create raised tactile patterns. 
            Designed for blind and visually impaired users with haptic feedback.
          </p>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Watch Display */}
          <div className="flex flex-col gap-6">
            <Card className="bg-slate-800/50 border-slate-700 p-8">
              <WatchFace hours={hours} minutes={minutes} />
            </Card>

            {/* Time Controls */}
            <Card className="bg-slate-800/50 border-slate-700 p-6">
              <h3 className="text-white mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Time Controls
              </h3>
              
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-slate-300">Hours: {hours.toString().padStart(2, '0')}</label>
                  </div>
                  <Slider
                    value={[hours]}
                    onValueChange={(value) => {
                      setHours(value[0]);
                      setUseRealTime(false);
                    }}
                    min={0}
                    max={23}
                    step={1}
                    disabled={useRealTime}
                  />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <label className="text-slate-300">Minutes: {minutes.toString().padStart(2, '0')}</label>
                  </div>
                  <Slider
                    value={[minutes]}
                    onValueChange={(value) => {
                      setMinutes(value[0]);
                      setUseRealTime(false);
                    }}
                    min={0}
                    max={59}
                    step={1}
                    disabled={useRealTime}
                  />
                </div>

                <Button 
                  onClick={toggleRealTime} 
                  className="w-full"
                  variant={useRealTime ? "default" : "outline"}
                >
                  {useRealTime ? 'Using Real Time' : 'Use Real Time'}
                </Button>
              </div>
            </Card>
          </div>

          {/* Information Tabs */}
          <div>
            <Tabs defaultValue="specs" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-slate-800/50">
                <TabsTrigger value="specs" className="data-[state=active]:bg-slate-700">
                  <Info className="w-4 h-4 mr-2" />
                  Specs
                </TabsTrigger>
                <TabsTrigger value="mechanism" className="data-[state=active]:bg-slate-700">
                  <Waves className="w-4 h-4 mr-2" />
                  Mechanism
                </TabsTrigger>
                <TabsTrigger value="haptics" className="data-[state=active]:bg-slate-700">
                  <Vibrate className="w-4 h-4 mr-2" />
                  Haptics
                </TabsTrigger>
              </TabsList>

              <TabsContent value="specs" className="mt-4">
                <TechnicalSpecs />
              </TabsContent>

              <TabsContent value="mechanism" className="mt-4">
                <Card className="bg-slate-800/50 border-slate-700 p-6">
                  <h3 className="text-white mb-4">Sand-Magnet Mechanism</h3>
                  <div className="space-y-4 text-slate-300">
                    <div>
                      <h4 className="text-white mb-2">How it works:</h4>
                      <ul className="space-y-2 list-disc list-inside">
                        <li>Ferromagnetic sand particles (iron-coated silica)</li>
                        <li>Electromagnetic grid beneath the watch face</li>
                        <li>Selective magnetization creates raised patterns</li>
                        <li>Patterns update every minute with smooth transitions</li>
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="text-white mb-2">Advantages:</h4>
                      <ul className="space-y-2 list-disc list-inside">
                        <li>Dynamic tactile display that can change shape</li>
                        <li>No moving mechanical parts to wear out</li>
                        <li>Low power consumption (only active during updates)</li>
                        <li>Smooth surface when deactivated</li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-white mb-2">Materials:</h4>
                      <ul className="space-y-2 list-disc list-inside">
                        <li>Flexible membrane top layer</li>
                        <li>Microencapsulated magnetic sand</li>
                        <li>Electromagnetic coil array (4x24 grid)</li>
                        <li>Water-resistant casing (IP67 rated)</li>
                      </ul>
                    </div>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="haptics" className="mt-4">
                <HapticDemo hours={hours} minutes={minutes} />
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Detailed Mechanism Section */}
        <div className="mt-12">
          <div className="text-center mb-8">
            <h2 className="text-white mb-2">How the Mechanism Works</h2>
            <p className="text-slate-400">
              Explore the inner workings of the sand-magnet tactile display system
            </p>
          </div>
          <MechanismDetail />
        </div>

        {/* Smart Features Section */}
        <div className="mt-12">
          <div className="text-center mb-8">
            <h2 className="text-white mb-2">Smart Features</h2>
            <p className="text-slate-400">
              Beyond timekeeping: health monitoring, navigation, and intelligent assistance
            </p>
          </div>
          <AdditionalFeatures />
        </div>
      </div>
    </div>
  );
}
