import { Card } from './ui/card';
import { Battery, Ruler, Weight, Droplet, Zap, Grid3x3 } from 'lucide-react';

export function TechnicalSpecs() {
  const specs = [
    {
      icon: Ruler,
      label: 'Dimensions',
      value: '42mm diameter',
      detail: '12mm thickness'
    },
    {
      icon: Weight,
      label: 'Weight',
      value: '68g',
      detail: 'Including band'
    },
    {
      icon: Grid3x3,
      label: 'Display Grid',
      value: '24×4 particles',
      detail: '96 tactile points'
    },
    {
      icon: Zap,
      label: 'Power',
      value: 'Electromagnetic',
      detail: '0.5W peak consumption'
    },
    {
      icon: Battery,
      label: 'Battery Life',
      value: '7 days',
      detail: 'With haptic feedback'
    },
    {
      icon: Droplet,
      label: 'Water Resistance',
      value: 'IP67',
      detail: '1m for 30 minutes'
    }
  ];

  return (
    <Card className="bg-slate-800/50 border-slate-700 p-6">
      <h3 className="text-white mb-6">Technical Specifications</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {specs.map((spec, index) => {
          const Icon = spec.icon;
          return (
            <div 
              key={index}
              className="flex items-start gap-3 p-4 bg-slate-900/50 rounded-lg border border-slate-700/50"
            >
              <div className="mt-1">
                <Icon className="w-5 h-5 text-amber-500" />
              </div>
              <div>
                <div className="text-slate-400 text-sm">{spec.label}</div>
                <div className="text-white">{spec.value}</div>
                <div className="text-slate-500 text-sm">{spec.detail}</div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 pt-6 border-t border-slate-700">
        <h4 className="text-white mb-4">Key Features</h4>
        <ul className="space-y-2 text-slate-300">
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-1">•</span>
            <span>Dynamic tactile display using ferromagnetic sand particles</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-1">•</span>
            <span>Haptic feedback for hourly chimes and alarms</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-1">•</span>
            <span>Voice assistant for settings and notifications</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-1">•</span>
            <span>Wireless charging compatible</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-amber-500 mt-1">•</span>
            <span>Bluetooth connectivity for smartphone integration</span>
          </li>
        </ul>
      </div>
    </Card>
  );
}
